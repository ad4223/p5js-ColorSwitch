//VARIABLES
//angle variable that will be used for rotating the squares
let angle = 0.1;
//variables for the x and y position of the ball
let ballY = 420;
let ballX = 200;
//variables for the x value of the lines that I will be using as a challenge
let bluelinex = 0; 
let purplelinex = 100; 
let pinklinex = 200; 
let yellowlinex = 300; 
let movinglinespeed = 1;
//booleans for the three different screens that will pop up
let gamerun = false;
let win = false;
let death = false;


function setup() {
  background(0);
  createCanvas(400, 460);
  //I'll be using degrees to rotate my squares so I declared it here.
  angleMode(DEGREES);
}

function draw() {
//This is the first page that will show up once the code runs
  textSize(30);
  fill(255);
  text("COLOR SWITCH", 80, 160);
  rect(120, 240, 140, 90);
  fill(0);
  text("START", 140, 290);

//There is another function all the way at the end which makes it so that when the player hits anywhere in the white rectangle, the game starts. When the game does start this code runs; a conditional.
  if (gamerun == true) {
    background(0);
    //drawing of the ball
    noStroke();
    fill(0, 255, 225);
    ellipse(ballX, ballY, 10);
    //As long as the r value of the ball is 0 which is also the same r value of the aqua color and a key is pressed, the ball will go up by 1 and if not then it will go down by 1.
    if (keyIsPressed === true && get(ballX, ballY)[0]==0) {
      ballY -= 1;
    } else {
      ballY += 1;
    }

//FIRST LINE CHALLENGE
    //all the lines have the same y position, width and height. The only thing that is different is their x value which are the variables I declared and initalized in the beginning. When the x value of the lines hit 400, the x value changes back to 0. I wish I could make it look neater, but this is what I have so far.
    //BLUE
    fill (0, 255, 255)
    rect(bluelinex, 30, 100, 10); 
    bluelinex = bluelinex + movinglinespeed
    if(bluelinex>=400){
      bluelinex = 0; 
    }
    //PURPLE
    fill (155, 0, 250); 
    rect(purplelinex, 30, 100, 10)
    purplelinex = purplelinex + movinglinespeed
    if(purplelinex>=400){
      purplelinex = 0; 
    }
    //PINK
    fill(230, 0, 130); 
    rect(pinklinex, 30, 100, 10); 
    pinklinex = pinklinex + movinglinespeed
    if (pinklinex>=400){
      pinklinex = 0;
    }
    //YELLOW
    fill(250, 250, 0); 
    rect(yellowlinex, 30, 100, 10); 
    yellowlinex = yellowlinex + movinglinespeed
    if (yellowlinex>=400){
      yellowlinex = 0; 
    }
    
//SECOND LINE CHALLENGE
    //BLUE
    fill (0, 255, 255)
    rect(bluelinex, 250, 100, 10); 
    bluelinex = bluelinex + movinglinespeed
    if(bluelinex>=400){
      bluelinex = 0; 
    }
    //PURPLE
    fill (155, 0, 250); 
    rect(purplelinex, 250, 100, 10)
    purplelinex = purplelinex + movinglinespeed
    if(purplelinex>=400){
      purplelinex = 0; 
    }
    //PINK
    fill(230, 0, 130); 
    rect(pinklinex, 250, 100, 10); 
    pinklinex = pinklinex + movinglinespeed
    if (pinklinex>=400){
      pinklinex = 0;
    }
    //YELLOW
    fill(250, 250, 0); 
    rect(yellowlinex, 250, 100, 10); 
    yellowlinex = yellowlinex + movinglinespeed
    if (yellowlinex>=400){
      yellowlinex = 0; 
    }
    
//FIRST SQAURE CHALLENGE
    //I'm drawing four different rectangles with different color, x value and y value that look like lines and spinning them at the same rate so they look like a sqaure. What push does is save and what pop does is restore. What it does is that this piece of code as it translates will only be contained within this section. The translation here will not affect the translation of more squares that I would like to animate.
    push();
    rectMode(CENTER);
    translate(200, 350);
    rotate(angle / 2);
    fill(0, 255, 225); //blue
    rect(0, -25, 50, 5);
    fill(155, 0, 250); //purple
    rect(-25, 0, 5, 50);
    fill(250, 250, 0); //yellow
    rect(25, 0, 5, 50);
    fill(230, 0, 130); //pink
    rect(0, 25, 50, 5);
    pop();

//SECOND SQAURE CHALLENGE
    push();
    rectMode(CENTER);
    translate(200, 150);
    rotate(angle);
    angle = angle + 1;
    fill(0, 255, 225);  //blue
    rect(0, -30, 60, 5);
    fill(155, 0, 250);  //purple
    rect(-30, 0, 5, 60);
    fill(250, 250, 0);  //yellow
    rect(30, 0, 5, 60);
    fill(230, 0, 130);  //blue
    rect(0, 30, 60, 5);
    pop();
    
  
//If the r balue of the x and y position of where the ball is doesn't equal to zero, then another page will open where the player dies. 
    if (get(ballX, ballY-5)[0] != 0) {
      death = true;
    }
    //When the player does die, this code will run
    if (death == true){
      background(0); 
      fill(255);
      textSize(30);
      text("YOU DIED!", 130, 200);
      textSize(15);
      text("Press play to restart", 140, 300);
    }
//By the time the ball reaches 25 as their y value after the last challenge, the player will win. 
    if (ballY==25){
      win = true; 
    }
    //When the player does win, this code will run bringing them back to the first page when they hit the play button.
    if (win == true){
      background(0); 
      fill(255); 
      textSize(30); 
      text("YOU WON!", 140, 200);
      textSize(15); 
      text("Press play to restart", 120, 300);
    }
  }
}
//Once the player clicks anywhere in the white rectangle of the first page, gamerun boolean is true. When it is true, the code where I wrote the conditional about gamerun will run.
function mousePressed() {
  if (mouseX > 120 && mouseX < 260 && mouseY > 240 && mouseY < 330) {
    gamerun = true;
  }
}